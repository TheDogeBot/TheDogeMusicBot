from DogeTheMusicBot.function.admins import admins
from DogeTheMusicBot.function.admins import get
from DogeTheMusicBot.function.admins import set

__all__ = ["set", "get", "admins"]
